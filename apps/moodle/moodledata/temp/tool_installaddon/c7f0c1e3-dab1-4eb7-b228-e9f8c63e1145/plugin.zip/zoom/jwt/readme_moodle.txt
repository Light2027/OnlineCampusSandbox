firebase/php-jwt : https://github.com/firebase/php-jwt

From the php-jwt repository, copy the files in src/ to this directory.
